const db = require("../models");

const Clubs = db.clubs;

const getClub = async () => {};

const getAllClubs = async () => {};

const getClubsByDistance = async () => {};

module.exports = {
	getClub,
	getAllClubs,
	getClubsByDistance,
};
